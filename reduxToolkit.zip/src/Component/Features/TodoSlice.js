import { createSlice, nanoid } from "@reduxjs/toolkit";

export const TodoSlice = createSlice({
    name: 'todo',
    initialState: {
        todos: [
            {
                id: 1,
                task: 'to code'
            },
        ]
    },
    reducers: {
        addTodo: (state, action) => {
            const todo = {
                id: nanoid(),
                task: action.payload
            }
            state.todos.push(todo);
        },
        removeTodo: (state, action) => {
            state.todos = state.todos.filter((todo) => todo.id !== action.payload)
        },
        updateTodo: (state, action) => {
            const { id, task } = action.payload;
            const data = state.todos.find((item)=>item.id===id);
            if(data){
                data.task = task
            }


        }
    }
})
export const { addTodo, removeTodo, updateTodo } = TodoSlice.actions;
export default TodoSlice.reducer;
