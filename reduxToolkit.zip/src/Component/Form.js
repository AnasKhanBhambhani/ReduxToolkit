import React, { useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { removeTodo, updateTodo } from './Features/TodoSlice';
import { addTodo } from './Features/TodoSlice';

const Form = () => {
  const [task, setTask] = useState();
  const [upd, setUpd] = useState(true);

  const dispatch = useDispatch();
  const data = useSelector(state => state.todos);
  const handleForm = (e) => {
    e.preventDefault();
    dispatch(addTodo(task))
    setTask('')

  }
  const removeTask = (id) => {
    dispatch(removeTodo(id))
  }
  const updateTask = (id,pretask) => {
    if(upd){
      setTask(pretask);
      setUpd(!upd);
    }
    else{
      dispatch(updateTodo(id,task))
      setTask('')
    }
  }


  return (
    <div className='bg-slate-300 flex flex-col gap-10 p-11 rounded shadow-2xl'>
      <div> <form className='flex flex-col gap-9' onSubmit={handleForm}>
        <div ><input type="text" value={task} onChange={(e) => { setTask(e.target.value) }} /></div>
        <div>
          <button className='bg-blue-500 px-4 py-2 rounded' type='submit'>Add Task</button>
        </div>
       
      </form>
      </div>
      <div>
          <button className='bg-blue-500 px-4 py-2 rounded' onClick={updateTask}>update Task</button>
        </div>
      <div> {
        data.map((item) => (
          <li key={item.id} className='list-none flex gap-3'>
            <div>{item.task}</div>
            <div className=' text-center '>
              <button onClick={() => { removeTask(item.id) }}>x</button>
            </div>
            <div className=' text-center '>
              <button onClick={() => { updateTask(item.id, item.task) }}>Update</button>
            </div>
          </li>
        ))
      }</div>

    </div>
  )
}

export default Form
