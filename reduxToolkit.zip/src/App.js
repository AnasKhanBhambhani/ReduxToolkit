import './App.css';
import Form from './Component/Form';
function App() {
  return (
    <div className='container bg-orange-500 h-[100vh]  flex justify-center items-center flex-col gap-10'>
<Form/>
  </div>
  );
}

export default App;
